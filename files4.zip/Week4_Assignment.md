# Week 4 Assignment – Introduction to Machine Learning

**Name:** Priyanshi Singh  |  **Internship:** Data Science, Next Gen Software Hub Pvt. Ltd.

---
## Section A: Theory Questions
1. What is Machine Learning? How is it different from traditional programming?
2. Explain supervised, unsupervised and reinforcement learning with one example each.
3. What is the difference between regression and classification?
4. Why do we split data into training and testing sets? What happens if we test on training data?
5. Define MAE, MSE, RMSE and R². When is R² negative?
6. What is overfitting? What is underfitting? How can each be reduced?
7. Despite its name, why is Logistic Regression used for classification?
8. What is data leakage? Why should `StandardScaler` be fitted only on training data?
9. What do precision, recall and F1-score mean? Give one situation where recall matters more than precision.
10. Read a confusion matrix: what do TP, TN, FP and FN stand for?

---
## Section B: Coding Tasks
**Task 1 – Linear Regression on a custom dataset**
Create a DataFrame with `hours_studied = [1,2,3,4,5,6,7,8]` and `marks = [35,42,50,55,62,70,78,85]`.
Train a Linear Regression model, print slope and intercept, and predict the marks for 9.5 hours.

**Task 2 – Diabetes dataset**
Using `load_diabetes`, train a model using only `bmi` and `s5`. Compare its R² with the model that uses all features. Which is better and why?

**Task 3 – Effect of split size**
Train the multiple regression model with `test_size` = 0.1, 0.2, 0.3, 0.4 and plot test R² vs test size.

**Task 4 – Classification on Wine dataset**
Load `sklearn.datasets.load_wine`. Scale the features, train a Logistic Regression model, and print accuracy, classification report and confusion matrix.

**Task 5 – Scaling comparison**
Train Logistic Regression on Iris with and without scaling. Compare accuracy and note the difference.

---
## Section C: Short Analysis
Write 5–6 lines: which model gave the best result this week, what its limitation is, and how you might improve it.

---
## Submission
- Save solutions in `Week4_Assignment_Solutions.ipynb`
- Push to GitHub along with the Week 4 folder
