# Week 4 – Introduction to Machine Learning

**Data Science Internship – Next Gen Software Hub Pvt. Ltd.**
**Intern:** Priyanshi Singh

## Objective
Understand the basics of Machine Learning and build first regression and classification models using scikit-learn.

## Topics Covered
- Types of ML (supervised, unsupervised, reinforcement)
- Train/test split
- Simple & Multiple Linear Regression
- Regression metrics: MAE, MSE, RMSE, R²
- Overfitting vs Underfitting
- Logistic Regression, feature scaling
- Classification metrics: accuracy, precision, recall, F1, confusion matrix

## Datasets (built into scikit-learn – no download needed)
| Dataset | Task | Target |
|---|---|---|
| Diabetes (442 rows, 10 features) | Regression | Disease progression score |
| Iris (150 rows, 4 features) | Classification | Species (3 classes) |

## Files
| File | Description |
|---|---|
| `Week4_Intro_to_ML.ipynb` | Main notebook with full code |
| `Week4_Assignment.md` | Practice questions and coding tasks |
| `Week4_Project_Report.docx` | Report of the week's work |
| `README.md` | This file |

## Libraries
`numpy`, `pandas`, `matplotlib`, `seaborn`, `scikit-learn`

```bash
pip install numpy pandas matplotlib seaborn scikit-learn jupyter
```

## How to Run
1. Download all files into one folder.
2. Run `jupyter notebook`.
3. Open `Week4_Intro_to_ML.ipynb` and choose **Kernel → Restart & Run All**.

## Key Results
| Model | MAE | RMSE | R² |
|---|---|---|---|
| Simple Linear Regression (BMI) | 52.26 | 63.73 | 0.233 |
| Multiple Linear Regression | 42.79 | 53.85 | 0.453 |

Logistic Regression on Iris: **93.3% accuracy** on the test set.

## Learning Outcome
Learned the complete basic ML workflow: load data → explore → split → train → predict → evaluate.
